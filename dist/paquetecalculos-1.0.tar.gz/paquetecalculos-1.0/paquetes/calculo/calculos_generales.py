def sumar(op1, op2):
	print("el resultado de la suma es: ", op1+op2)

def restar(op1, op2):
	print("el resultado de la restar es: ", op1-op2)

def multiplicar(op1, op2):
	print("el resultado de la multiplicacion es: ", op1*op2)

def exponente(base, exponente):
	print("el resultado de la exponente es: ", base**exponente)

def redondear(numero):
	print("el numero redondeado es: ", round(numero))
