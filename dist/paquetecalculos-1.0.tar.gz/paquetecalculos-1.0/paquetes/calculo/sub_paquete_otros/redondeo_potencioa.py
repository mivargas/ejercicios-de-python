
def exponente(base, exponente):
	print("el resultado de la exponente es: ", base**exponente)

def redondear(numero):
	print("el numero redondeado es: ", round(numero))
